import bhargav from './Team_img/Bhargav.jpeg'
import vikram from './Team_img/vikram.jpeg'
import sanjay from './Team_img/sanjay.jpeg'
import anil from './Team_img/anil.jpeg'
import manoj from './Team_img/manoj.jpeg'
import Rejnu from './Team_img/renju.jpeg'
import shivendra from './Team_img/shivendra.jpeg'
import milan from './Team_img/milan.jpg'
import shyam from './Team_img/shyam.jpeg'
import jyoti from './Team_img/jyoti.jpg'
import uday from './Team_img/uday.jpg'
import rajnish from './Team_img/rajnish jaiswal.png'
export const Data = [
    {
        Name:'Bhargav Trivedi',
        Desc : 'Senior Director of Software Engineering',
        linkedin :'https://www.linkedin.com/in/bhargav-trivedi-28547215/?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
        img : bhargav,
    },
    {
        Name:'Rajnish Jaiswal',
        Desc : 'Philanthropist and Industrialist',
        linkedin :'https://www.linkedin.com/in/rajnish-jaiswal-55342514?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
        img : rajnish,
    },
     
    {
        Name:'Sanjay K. Singh',
        Desc : 'Senior Enterprise Architect',
        linkedin :'https://www.linkedin.com/in/sanjay-kumar-singh-42a2523?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
        img : sanjay ,
    },
    // {
    //     Name:'Anil Khatri',
    //     Desc : 'Engineering Manager and Solution Architect',
    //     linkedin :'https://www.linkedin.com/in/anil-khatri-4962a82?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
    //     img : anil,
    // },
    {
        Name:'Manoj Behl',
        Desc : 'Senior Solutions Architect',
        linkedin :'https://www.linkedin.com/in/manoj-behl-8822038?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
        img :manoj ,
    },
    {
        Name:'Renju Karunakaran',
        Desc : 'Director of Software Engineering at Cloudstry',
        linkedin :'https://www.linkedin.com/in/renju-karunakaran-2a4705126?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
        img : Rejnu,
    },
    {
        Name:'Milan K. Nayak',
        Desc : 'Technology Analyst at Cloudstry',
        linkedin :'https://www.linkedin.com/in/milan-kumar-nayak-317614224/?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
        img : milan,
    },
    {
        Name:'Shyam M. Singh',
        Desc : 'Technology Analyst at Cloudstry',
        linkedin :'https://www.linkedin.com/in/shyam-mohan-singh-408676203?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app',
        img : shyam,
    },
    {
        Name:'Shivendra kadam',
        Desc : 'Technology Analyst at Cloudstry',
        linkedin :'https://www.linkedin.com/in/shivendra-kadam-0a2390281/',
        img : shivendra,
    },
    {
        Name:'Jyoti Hariyale',
        Desc : 'Technology Analyst at Cloudstry',
        linkedin :'https://www.linkedin.com/in/jyoti-hariyale/',
        img : jyoti,
    },
    {
        Name:'Uday Solanki',
        Desc : 'Technology Analyst - Intern at Cloudstry',
        linkedin :'https://www.linkedin.com/in/udaysolankii/',
        img : uday,
    },
]